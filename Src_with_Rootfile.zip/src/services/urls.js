export const AUTH ={
    SIGNIN: 'auth/login'
}