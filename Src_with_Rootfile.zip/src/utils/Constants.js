export const STATIC_TXT = {
    LOGIN: 'Login'
}