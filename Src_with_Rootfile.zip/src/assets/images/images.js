export const LOGO = require('../images/logo.png');
export const HOME = require('../images/home.png');
export const ACTIVE_HOME = require('../images/active-home.png');
export const PRODUCT = require('../images/product.png');
export const ACTIVE_PRODUCT = require('../images/active-product.png');
export const PROFILE = require('../images/profile.png');
export const ACTIVE_PROFILE = require('../images/active-profile.png');
